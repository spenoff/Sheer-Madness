/*
    Unused class
*/

export class Dog {

    constructor(game, player, sheepGroup, fencesGroup) {
        this.game = game;
        this.player = player;
        this.sheepGroup = sheepGroup;
        this.fencesGroup = fencesGroup;
    }

    setGame(game) {
        this.game = game;
    }

    setPlayer(player) {
        this.player = player;
    }

    setSheep(sheepGroup) {
        this.sheepGroup = sheepGroup;
    }

    setFencesGroup(fencesGroup) {
        this.fencesGroup = fencesGroup;
    }



    //contain the dog object

    //bark

    /*
    What does the dog need to know about?
    */
}